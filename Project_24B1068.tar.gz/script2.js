let matchData = JSON.parse(localStorage.getItem("matchData")) || {};
let gameState = JSON.parse(localStorage.getItem("gameState")) || {
  currentInning: 1,
  innings: [
    { battingTeam: matchData.team1, bowlingTeam: matchData.team2, score: 0, wickets: 0, balls: 0, batsmen: {}, bowlers: {} },
    { battingTeam: matchData.team2, bowlingTeam: matchData.team1, score: 0, wickets: 0, balls: 0, batsmen: {}, bowlers: {} }
  ],
  striker: null,
  nonStriker: null,
  bowler: null
};

function setPlayers() {
  let striker = document.getElementById("strikerInput").value;
  let nonStriker = document.getElementById("nonStrikerInput").value;
  let bowler = document.getElementById("bowlerInput").value;

  gameState.striker = striker;
  gameState.nonStriker = nonStriker;
  gameState.bowler = bowler;

  document.getElementById("currentStriker").innerText = striker;
  document.getElementById("currentNonStriker").innerText = nonStriker;
  document.getElementById("currentBowler").innerText = bowler;

  saveState();
}

function addRuns(runs) {
  let inning = gameState.innings[gameState.currentInning - 1];
  inning.score += runs;
  inning.balls++;

  // update striker stats
  if (!inning.batsmen[gameState.striker]) {
    inning.batsmen[gameState.striker] = { runs: 0, balls: 0 };
  }
  inning.batsmen[gameState.striker].runs += runs;
  inning.batsmen[gameState.striker].balls += 1;

  // update bowler stats
  if (!inning.bowlers[gameState.bowler]) {
    inning.bowlers[gameState.bowler] = { runs: 0, balls: 0 };
  }
  inning.bowlers[gameState.bowler].runs += runs;
  inning.bowlers[gameState.bowler].balls += 1;

  // rotate strike on odd runs
  if (runs % 2 !== 0) {
    [gameState.striker, gameState.nonStriker] = [gameState.nonStriker, gameState.striker];
  }

  // end over = 6 balls
  if (inning.balls % 6 === 0) {
    [gameState.striker, gameState.nonStriker] = [gameState.nonStriker, gameState.striker];
  }

  updateScore();
  checkEndInning();
  saveState();
}

function addWicket() {
  let inning = gameState.innings[gameState.currentInning - 1];
  inning.wickets += 1;
  inning.balls++;

  // add ball to bowler
  if (!inning.bowlers[gameState.bowler]) {
    inning.bowlers[gameState.bowler] = { runs: 0, balls: 0 };
  }
  inning.bowlers[gameState.bowler].balls += 1;

  updateScore();
  checkEndInning();
  saveState();
}

function updateScore() {
  let inning = gameState.innings[gameState.currentInning - 1];
  document.getElementById("totalScore").innerText = `${inning.score}/${inning.wickets}`;
  
  let overs = Math.floor(inning.balls / 6);
  let balls = inning.balls % 6;
  document.getElementById("totalOvers").innerText = `${overs}.${balls}`;
}


function checkEndInning() {
  let inning = gameState.innings[gameState.currentInning - 1];
  let overLimit = 12; // 2 overs = 12 balls

  if (
    inning.wickets >= 10 ||
    inning.balls >= overLimit ||
    (gameState.currentInning === 2 &&
      inning.score > gameState.innings[0].score)
  ) {
    alert("Inning over!");
    if (gameState.currentInning === 1) {
      gameState.currentInning = 2;
    } else {
      alert("Match Over!");
    }
  }
}

function showInning(num) {
  let display = document.getElementById("inningDisplay");
  let inning = gameState.innings[num - 1];
  let html = `<h2>${inning.battingTeam} Batting</h2><table border="1"><tr><th>Name</th><th>Runs</th><th>Balls</th><th>SR</th></tr>`;

  for (let [name, stats] of Object.entries(inning.batsmen)) {
    let sr = ((stats.runs / stats.balls) * 100).toFixed(2);
    html += `<tr><td>${name}</td><td>${stats.runs}</td><td>${stats.balls}</td><td>${sr}</td></tr>`;
  }

  html += `</table><h3>${inning.bowlingTeam} Bowling</h3><table border="1"><tr><th>Name</th><th>Runs</th><th>Overs</th><th>Eco</th></tr>`;

  for (let [name, stats] of Object.entries(inning.bowlers)) {
    let overs = Math.floor(stats.balls / 6) + "." + (stats.balls % 6);
    let eco = (stats.runs / (stats.balls / 6)).toFixed(2);
    html += `<tr><td>${name}</td><td>${stats.runs}</td><td>${overs}</td><td>${eco}</td></tr>`;
  }

  html += `</table>`;
  display.innerHTML = html;
}

function saveState() {
  localStorage.setItem("gameState", JSON.stringify(gameState));
}

