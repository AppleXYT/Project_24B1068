let gameState = JSON.parse(localStorage.getItem("gameState"));
let summaryDiv = document.getElementById("summary");

function isInningOver(inning) {
  return inning.wickets >= 10 || inning.balls >= 12;
}

if (!gameState || gameState.currentInning < 2) {
  summaryDiv.innerText = "Match Ongoing...";
} else {
  let firstInning = gameState.innings[0];
  let secondInning = gameState.innings[1];

  // Check if both innings are over
  const firstInningOver = isInningOver(firstInning);
  const secondInningOver = isInningOver(secondInning) || secondInning.score > firstInning.score;

  if (firstInningOver && secondInningOver) {
    let winner = "";
    let margin = "";

    if (secondInning.score > firstInning.score) {
      let wicketsLeft = 10 - secondInning.wickets;
      winner = secondInning.battingTeam;
      margin = `${wicketsLeft} wicket${wicketsLeft !== 1 ? 's' : ''}`;
    } else if (firstInning.score > secondInning.score) {
      let runsAhead = firstInning.score - secondInning.score;
      winner = firstInning.battingTeam;
      margin = `${runsAhead} run${runsAhead !== 1 ? 's' : ''}`;
    } else {
      summaryDiv.innerText = "The match ended in a tie!";
      return;
    }

    summaryDiv.innerText = `${winner} won the match by ${margin}`;
  } else {
    summaryDiv.innerText = "Match Ongoing...";
  }
}



