function setMatch() {
  // Get input values
  var team1 = document.getElementById("team1").value;
  var team2 = document.getElementById("team2").value;
  var tossWinner = document.getElementById("tossWinner").value;
  var tossDecision = document.getElementById("tossDecision").value;

  // Reset and update localStorage
  localStorage.removeItem("matchData");

  var matchData = {
    team1: team1,
    team2: team2,
    tossWinner: tossWinner,
    tossDecision: tossDecision
  };

  localStorage.setItem("matchData", JSON.stringify(matchData));

  alert("Match data saved!");
}

// When typing team names, update toss winner dropdown
document.getElementById("team1").addEventListener("input", updateTossOptions);
document.getElementById("team2").addEventListener("input", updateTossOptions);

function updateTossOptions() {
  var team1 = document.getElementById("team1").value;
  var team2 = document.getElementById("team2").value;
  var tossDropdown = document.getElementById("tossWinner");

  tossDropdown.innerHTML = '<option value="">Choose Toss Winner</option>';
  if (team1) {
    tossDropdown.innerHTML += '<option value="' + team1 + '">' + team1 + '</option>';
  }
  if (team2) {
    tossDropdown.innerHTML += '<option value="' + team2 + '">' + team2 + '</option>';
  }
}
